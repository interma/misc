# add global variable
check_result = False
suffix = False
