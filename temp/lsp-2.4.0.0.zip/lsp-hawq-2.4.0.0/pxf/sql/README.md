# DDL For TPC-H tables

1. Run `hive.sql` first
2. Before running `hawq_external_tables.sql` change the location IP to the namenode of your cluster
